{*
 * Seguimiento público de una reparación (/seguimiento). Página propia, sin el tema de la tienda.
 *}<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
{if $state == 'ok' && isset($tech) && $tech && $tech.avatar}
<meta property="og:title" content="Tu {$r.device|escape:'html':'UTF-8'} · te atiende {$tech.name|escape:'html':'UTF-8'}">
<meta property="og:description" content="{$r.status_name|escape:'html':'UTF-8'} · {$shop.name|escape:'html':'UTF-8'}">
<meta property="og:image" content="{$tech.avatar|escape:'html':'UTF-8'}">
<meta property="og:type" content="website">
{/if}
<title>{if $state == 'device'}{$device|escape:'html':'UTF-8'}{else}Seguimiento{/if}{if $state == 'ok'} {$r.reference|escape:'html':'UTF-8'}{/if} · {$shop.name|escape:'html':'UTF-8'}</title>
<style>
  :root { --bg:#F4F5F7; --card:#FFFFFF; --fg:#14161A; --fg2:#5B6170; --line:#D5D8DE; --line2:#EEF0F2; --pri:#0B6E4B; }
  * { box-sizing: border-box; }
  body { margin: 0; background: var(--bg); color: var(--fg); font: 15px/1.5 -apple-system, "Segoe UI", Roboto, Inter, Arial, sans-serif; -webkit-font-smoothing: antialiased; }
  .wrap { max-width: 560px; margin: 0 auto; padding: 20px 16px 40px; }
  .top { text-align: center; margin-bottom: 16px; }
  .top img { max-height: 48px; max-width: 200px; }
  .top .shop { font-weight: 700; margin-top: 6px; }
  .card { background: var(--card); border: 1px solid var(--line2); border-radius: 16px; box-shadow: 0 1px 2px rgba(20,22,26,.08); padding: 20px; margin-bottom: 14px; animation: in .4s cubic-bezier(.2,.8,.2,1) both; }
  .card:nth-child(3) { animation-delay: .06s; } .card:nth-child(4) { animation-delay: .12s; }
  @keyframes in { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: none; } }
  h1 { font-size: 22px; margin: 0 0 4px; letter-spacing: -.01em; }
  .muted { color: var(--fg2); font-size: 14px; }
  .chip { display: inline-flex; align-items: center; gap: 8px; font-weight: 700; font-size: 16px; padding: 8px 14px; border-radius: 999px; background: var(--line2); margin: 12px 0 8px; }
  .dot { width: 12px; height: 12px; border-radius: 50%; }
  .steps { display: grid; grid-template-columns: repeat(6, 1fr); gap: 4px; margin: 14px 0 6px; }
  .steps div { height: 8px; border-radius: 999px; background: var(--line2); }
  .steps .done { background: linear-gradient(135deg, #17A673, #0B6E4B); }
  .steps .cur { background: linear-gradient(135deg, #17A673, #0B6E4B); animation: pulse 1.6s ease-in-out infinite; }
  @keyframes pulse { 50% { opacity: .45; } }
  .labels { display: grid; grid-template-columns: repeat(6, 1fr); gap: 4px; font-size: 10px; color: var(--fg2); text-align: center; }
  .kv { display: flex; justify-content: space-between; gap: 12px; padding: 8px 0; border-top: 1px solid var(--line2); }
  .kv:first-child { border-top: 0; }
  .kv b { text-align: right; }
  .tag { display: inline-block; font-size: 12px; font-weight: 700; border-radius: 999px; padding: 3px 10px; background: #FCF0CC; color: #6B4A00; }
  .btn { display: block; width: 100%; min-height: 50px; border-radius: 12px; border: 0; background: linear-gradient(135deg, #17A673, #0B6E4B); color: #fff; font: 700 16px/50px inherit; font-family: inherit; text-align: center; text-decoration: none; cursor: pointer; box-shadow: 0 8px 18px -8px rgba(11,110,75,.6); }
  input { width: 100%; min-height: 52px; border: 1px solid var(--line); border-radius: 12px; padding: 0 14px; font: 600 20px/1 inherit; font-family: inherit; text-transform: uppercase; letter-spacing: .12em; text-align: center; margin: 10px 0; }
  .msg { border-radius: 12px; padding: 14px; background: #FBE1E1; color: #8A1C1C; margin-bottom: 14px; }
  .foot { text-align: center; font-size: 13px; color: var(--fg2); margin-top: 20px; }
  .foot a { color: var(--pri); }
  .tech { display: flex; align-items: center; gap: 16px; }
  .tech img, .tech .tav { width: 84px; height: 84px; border-radius: 50%; object-fit: cover; background: #DCFCE7; flex: none; }
  .tech .tav { display: grid; place-items: center; font-size: 30px; font-weight: 800; color: #0B6E4B; }
  .tech b { display: block; font-size: 20px; }
  .contact b { display: block; margin-bottom: 12px; }
  .cbtns { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
  .cbtn { display: flex; align-items: center; justify-content: center; gap: 8px; min-height: 52px; border-radius: 12px; font-weight: 700; font-size: 15px; text-decoration: none; }
  .cbtn svg { width: 22px; height: 22px; flex: none; }
  .cbtn.wa { background: #25D366; color: #fff; box-shadow: 0 8px 18px -8px rgba(37,211,102,.7); }
  .cbtn .ct { display: flex; flex-direction: column; line-height: 1.15; text-align: left; }
  .cbtn .ct small { font-size: 12px; font-weight: 600; color: var(--fg2); white-space: nowrap; }
  .cbtn.tel { background: #fff; color: var(--fg); border: 1px solid var(--line); }
  .addr { display: flex; align-items: center; gap: 10px; margin-top: 14px; padding: 12px; border-radius: 12px; background: var(--bg); color: var(--fg); text-decoration: none; font-weight: 600; }
  .addr svg { width: 22px; height: 22px; color: var(--pri); flex: none; }
  .addr small { display: block; color: var(--pri); font-weight: 600; font-size: 13px; }
  .hours { margin-top: 10px; font-size: 14px; }
  @media (max-width: 380px) { .cbtns { grid-template-columns: 1fr; } }
  @media (prefers-reduced-motion: reduce) { .card, .steps .cur { animation: none; } }
</style>
</head>
<body>
<div class="wrap">
  <div class="top">
    {if $shop.logo}<a href="{$shop.url|escape:'html':'UTF-8'}"><img src="{$shop.logo|escape:'html':'UTF-8'}" alt="{$shop.name|escape:'html':'UTF-8'}"></a>{/if}
    <div class="shop">{$shop.name|escape:'html':'UTF-8'}</div>
  </div>

  {if $state == 'ok'}
    <div class="card">
      <div class="muted">Reparación {$r.reference|escape:'html':'UTF-8'}</div>
      <h1>{$r.device|escape:'html':'UTF-8'}</h1>
      <div class="chip"><span class="dot" style="background:{$r.status_color|escape:'html':'UTF-8'}"></span>{$r.status_name|escape:'html':'UTF-8'}</div>
      {if $r.waiting_part}<div><span class="tag">Esperando una pieza</span></div>{/if}
      <p style="margin:8px 0 0">{$r.message|escape:'html':'UTF-8'}</p>
      {if $r.status != 'cancelled'}
        <div class="steps">{foreach from=$steps item=s}<div class="{if $s.done}done{elseif $s.current}cur{/if}"></div>{/foreach}</div>
        <div class="labels">{foreach from=$steps item=s}<span>{$s.name|escape:'html':'UTF-8'}</span>{/foreach}</div>
      {/if}
    </div>
    {if isset($tech) && $tech}
      <div class="card tech">
        {if $tech.avatar}<img src="{$tech.avatar|escape:'html':'UTF-8'}" alt="">{else}<span class="tav">{$tech.name|truncate:1:''|escape:'html':'UTF-8'}</span>{/if}
        <div><span class="muted">Te atiende</span><b>{$tech.name|escape:'html':'UTF-8'}</b></div>
      </div>
    {/if}
    {if $photos}
      <div class="card"><b>Fotos del trabajo</b>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:8px;margin-top:10px">
          {foreach from=$photos item=ph}<a href="{$ph.full|escape:'html':'UTF-8'}" target="_blank" rel="noopener"><img src="{$ph.thumb|escape:'html':'UTF-8'}" alt="" loading="lazy" style="width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:10px;display:block"></a>{/foreach}
        </div>
      </div>
    {/if}
    {if $quoteLink}
      <div class="card"><b>Tienes un presupuesto pendiente</b><p class="muted" style="margin:4px 0 12px">Revísalo y acéptalo para que empecemos la reparación.</p>
        <a class="btn" href="{$quoteLink|escape:'html':'UTF-8'}">Ver el presupuesto</a></div>
    {/if}
    <div class="card">
      <div class="kv"><span class="muted">Entrada</span><b>{$r.date_add|date_format:'%d/%m/%Y'}</b></div>
      {if $r.eta}<div class="kv"><span class="muted">Fecha prevista</span><b>{$r.eta|date_format:'%d/%m/%Y'}</b></div>{/if}
      <div class="kv"><span class="muted">Último cambio</span><b>{$r.date_status|date_format:'%d/%m/%Y %H:%M'}</b></div>
      {if $r.total > 0}<div class="kv"><span class="muted">Total</span><b>{$r.total|string_format:'%.2f'|replace:'.':','} €</b></div>{/if}
      {if $r.pending > 0 && $r.pending < $r.total}<div class="kv"><span class="muted">Pendiente de pago</span><b>{$r.pending|string_format:'%.2f'|replace:'.':','} €</b></div>{/if}
      {if $r.warranty}<div class="kv"><span class="muted">Garantía</span><b>Sí</b></div>{/if}
    </div>
  {elseif $state == 'battery'}
    <div class="card">
      <div class="muted">Batería fabricada en nuestro taller · {$bat.serial|escape:'html':'UTF-8'}</div>
      <h1>{$bat.data.volts|escape:'html':'UTF-8'} V · {$bat.data.ah|escape:'html':'UTF-8'} Ah{if $bat.data.wh} · {$bat.data.wh|escape:'html':'UTF-8'} Wh{/if}</h1>
      {if $bat.warranty_until}<div class="chip"><span class="dot" style="background:{if $bat.warranty_until >= $smarty.now|date_format:'%Y-%m-%d'}#0B6E4B{else}#B91C1C{/if}"></span>{if $bat.warranty_until >= $smarty.now|date_format:'%Y-%m-%d'}En garantía hasta el {$bat.warranty_until|date_format:'%d/%m/%Y'}{else}Garantía terminada el {$bat.warranty_until|date_format:'%d/%m/%Y'}{/if}</div>{/if}
    </div>
    <div class="card">
      {if $bat.data.config || $bat.data.cell}<div class="kv"><span class="muted">Celdas</span><b>{$bat.data.config|escape:'html':'UTF-8'} {$bat.data.chem|escape:'html':'UTF-8'} {$bat.data.cell|escape:'html':'UTF-8'}</b></div>{/if}
      {if $bat.data.bms}<div class="kv"><span class="muted">BMS</span><b>{$bat.data.bms|escape:'html':'UTF-8'}</b></div>{/if}
      {if $bat.data.conn_ctrl}<div class="kv"><span class="muted">Conector</span><b>{$bat.data.conn_ctrl|escape:'html':'UTF-8'}</b></div>{/if}
      {if $bat.data.conn_charge}<div class="kv"><span class="muted">Carga</span><b>{$bat.data.conn_charge|escape:'html':'UTF-8'}</b></div>{/if}
      {if $bat.data.for_model}<div class="kv"><span class="muted">Para</span><b>{$bat.data.for_model|escape:'html':'UTF-8'}</b></div>{/if}
      <div class="kv"><span class="muted">Fabricada</span><b>{$bat.date_add|date_format:'%d/%m/%Y'}</b></div>
    </div>
  {elseif $state == 'device'}
    <div class="card">
      <div class="muted">Tu patín · {$tag|escape:'html':'UTF-8'}</div>
      <h1>{$device|escape:'html':'UTF-8'}</h1>
      {if $openUrl}<p style="margin:8px 0 12px">Ahora mismo está en el taller.</p><a class="btn" href="{$openUrl|escape:'html':'UTF-8'}">Ver cómo va</a>{/if}
      {if $waUrl}<p style="margin:12px 0 0"><a class="btn" href="{$waUrl|escape:'html':'UTF-8'}" target="_blank" rel="noopener">Pedir revisión por WhatsApp</a></p>{/if}
    </div>
    <div class="card"><b>Historial en el taller</b>
      {foreach from=$rows item=x}
        <div class="kv"><span>{$x.date|date_format:'%d/%m/%Y'}</span><b><span class="dot" style="background:{$x.status_color|escape:'html':'UTF-8'};display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:6px"></span>{$x.status_name|escape:'html':'UTF-8'}{if $x.warranty_until} · garantía hasta {$x.warranty_until|date_format:'%d/%m/%Y'}{/if}</b></div>
      {/foreach}
    </div>
  {else}
    <div class="card">
      <h1>Seguimiento de tu reparación</h1>
      {if $state == 'notfound'}<div class="msg">No encontramos ninguna reparación con ese código. Revisa el resguardo.</div>{/if}
      {if $state == 'expired'}<div class="msg">Esta reparación se cerró hace tiempo y ya no se puede consultar.</div>{/if}
      {if $state == 'limit'}<div class="msg">Demasiados intentos. Prueba dentro de unos minutos.</div>{/if}
      <p class="muted">Escribe el código que aparece en tu resguardo (por ejemplo ABCD-1234) o escanea el QR.</p>
      <form method="get" action="{$action|escape:'html':'UTF-8'}">
        <input name="c" value="{$code|escape:'html':'UTF-8'}" maxlength="9" autocomplete="off" placeholder="ABCD-1234" aria-label="Código de seguimiento">
        <button type="submit" class="btn">Ver mi reparación</button>
      </form>
    </div>
  {/if}

  {if $shop.waLink || $shop.tel || $shop.address}
  <div class="card contact">
    <b>¿Tienes alguna duda? Háblanos</b>
    <div class="cbtns">
      {if $shop.waLink}<a class="cbtn wa" href="{$shop.waLink|escape:'html':'UTF-8'}" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2zm0 18.2c-1.5 0-3-.4-4.3-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8.2 8.2 0 1 1 12 20.2zm4.5-6.1c-.2-.1-1.5-.7-1.7-.8-.2-.1-.4-.1-.6.1l-.8 1c-.1.2-.3.2-.5.1a6.7 6.7 0 0 1-3.3-2.9c-.2-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.6-.4h-.5c-.2 0-.4.1-.7.3-.2.3-.9.9-.9 2.2s.9 2.5 1 2.7c.1.2 1.8 2.8 4.4 3.9 1.6.7 2.3.8 3.1.6.5-.1 1.5-.6 1.7-1.2.2-.6.2-1.1.2-1.2-.1-.1-.3-.2-.5-.3z"/></svg>WhatsApp</a>{/if}
      {if $shop.tel}<a class="cbtn tel" href="tel:{$shop.tel|escape:'html':'UTF-8'}"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/></svg><span class="ct">Llamar<small>{$shop.phone|escape:'html':'UTF-8'}</small></span></a>{/if}
    </div>
    {if $shop.address}<a class="addr" href="{$shop.maps|escape:'html':'UTF-8'}" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M12 22s7-6.1 7-12a7 7 0 0 0-14 0c0 5.9 7 12 7 12z"/><circle cx="12" cy="10" r="2.5" fill="none" stroke="currentColor" stroke-width="2"/></svg><span>{$shop.address|escape:'html':'UTF-8'}<small>Cómo llegar</small></span></a>{/if}
    {if $shop.hoursList}<div class="hours">{foreach from=$shop.hoursList item=h}<div class="kv"><span class="muted">{$h.d|escape:'html':'UTF-8'}</span><b>{$h.h|escape:'html':'UTF-8'}</b></div>{/foreach}</div>{/if}
  </div>
  {/if}

  <div class="foot">{$shop.name|escape:'html':'UTF-8'}{if $shop.address} · {$shop.address|escape:'html':'UTF-8'}{/if}</div>
</div>
</body>
</html>
